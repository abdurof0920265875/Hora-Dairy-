COBFCU Dairy Farm app (installable Android web app, works offline)

INSTALL ON ANDROID (needs the files on an https website once):
1. Upload this whole folder to a free host: Netlify Drop (app.netlify.com/drop), GitHub Pages or Cloudflare Pages.
2. Open the https link in Chrome on the phone > menu (3 dots) > "Install app" / "Add to Home screen".
3. After the first open it works with no internet. Data stays on the phone; use More > Save backup regularly.

QUICK TRY WITHOUT HOSTING: open COBFCU_Dairy_Farm_App_single_file.html in Chrome (not installable, but works offline).

TO GET A REAL .APK: after hosting, enter the link at pwabuilder.com > Package for Android.
